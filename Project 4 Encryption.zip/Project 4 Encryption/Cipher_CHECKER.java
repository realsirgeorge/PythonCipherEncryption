import java.util.Arrays;

public class Cipher_CHECKER {

    public static void main(String[] args) {
        // Example input
        String input = "Doritos > Lays, 29375336";

        // Split the input into the secret message and key
        String[] parts = input.split(", ");
        String secretMessage = parts[0];
        int key = Integer.parseInt(parts[1]);

        // Encrypt the message
        String encodedMessage = encrypt(secretMessage, key);

        // Decrypt the message
        String decodedMessage = decrypt(encodedMessage, key);
    }

    // Function to encrypt a message
    public static String encrypt(String message, int key) {
        // Convert the key to binary
        String binaryKeyStr = Integer.toBinaryString(key);

        String encrypted = message;

        for (int i = 0; i < binaryKeyStr.length(); i++) {
            if (binaryKeyStr.charAt(i) == '1') {
                encrypted = shuffle(encrypted);
            } else {
                encrypted = riffle(encrypted);
            }
        }

        return encrypted;
    }

    // Function to decrypt an encrypted message
    public static String decrypt(String message, int key) {
        // Reverse the binary representation of the key
        String binaryKey = new StringBuilder(Integer.toBinaryString(key)).reverse().toString();
        String decrypted = message;

        for (int i = 0; i < binaryKey.length(); i++) {
            if (binaryKey.charAt(i) == '1') {
                decrypted = unshuffle(decrypted);
            } else {
                decrypted = unriffle(decrypted);
            }
        }
        return decrypted;
    }

    // Custom operation 1: Shuffle
    public static String shuffle(String message) {
        int valueOfFirstThree = (int) message.charAt(0) + (int) message.charAt(1) + (int) message.charAt(2);
        int nextValue = (valueOfFirstThree + (int) message.charAt(0)) % 94 + 33;

        StringBuilder shuffled = new StringBuilder();
        for (char c : message.toCharArray()) {
            int encryptedAscii = ((int) c + nextValue - 33) % 94 + 33;
            shuffled.append((char) encryptedAscii);
            nextValue = (nextValue + 1) % 94 + 33;
        }

        return shuffled.toString();
    }

    // Custom operation 2: Riffle
    public static String riffle(String message) {
        int[] freqs = new int[128];
        Arrays.fill(freqs, 0);

        for (char c : message.toCharArray()) {
            if (c != ' ') {
                freqs[(int) c]++;
            }
        }

        int maxCount = 0;
        char mostFrequentChar = 0;
        for (int i = 0; i < freqs.length; i++) {
            if (freqs[i] > maxCount && i >= 33 && i <= 126) {
                mostFrequentChar = (char) i;
                maxCount = freqs[i];
            }
        }

        int index = message.length() / (maxCount + 1);
        return message.substring(index) + message.substring(0, index);
    }

    // Reverse of Custom operation 1: Unshuffle
    public static String unshuffle(String message) {
        int valueOfFirstThree = (int) message.charAt(0) + (int) message.charAt(1) + (int) message.charAt(2);
        int nextValue = (valueOfFirstThree + (int) message.charAt(0)) % 94 + 33;

        StringBuilder unshuffled = new StringBuilder();
        for (char c : message.toCharArray()) {
            int originalAscii = ((int) c - nextValue + 94) % 94 + 33;
            unshuffled.append((char) originalAscii);
            nextValue = (nextValue + 1) % 94 + 33;
        }

        return unshuffled.toString();
    }

    // Reverse of Custom operation 2: Unriffle
    public static String unriffle(String message) {
        int[] freqs = new int[128];
        Arrays.fill(freqs, 0);

        for (char c : message.toCharArray()) {
            if (c != ' ') {
                freqs[(int) c]++;
            }
        }

        int maxCount = 0;
        char mostFrequentChar = 0;
        for (int i = 0; i < freqs.length; i++) {
            if (freqs[i] > maxCount && i >= 33 && i <= 126) {
                mostFrequentChar = (char) i;
                maxCount = freqs[i];
            }
        }

        int index = message.length() / (maxCount + 1);
        return message.substring(index) + message.substring(0, index);
    }
}
